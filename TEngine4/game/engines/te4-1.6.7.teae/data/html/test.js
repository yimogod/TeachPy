$('strong').click(function() {
	$(this).html("CLICKED");
});